package com.vsawk.insurance;

import io.github.cdimascio.dotenv.Dotenv;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class VehicleInsuranceApplication {
    private static final Logger logger = LoggerFactory.getLogger(VehicleInsuranceApplication.class);
    public static void main(String[] args) {
        Dotenv dotenv = Dotenv.configure()
                              .ignoreIfMissing()
                              .load();

        String dbUser = dotenv.get("DB_USERNAME");
        String dbPass = dotenv.get("DB_PASSWORD");

        if (dbUser != null) {
            System.setProperty("DB_USERNAME", dbUser);
        } else {
            logger.warn("DB_USERNAME is not set in .env");
        }

        if (dbPass != null) {
            System.setProperty("DB_PASSWORD", dbPass);
        } else {
            logger.warn("DB_PASSWORD is not set in .env");
        }

        SpringApplication.run(VehicleInsuranceApplication.class, args);
    }
}