//“Run AuthInterceptor on every request before hitting any controller.”

package com.vsawk.insurance.config;
import com.vsawk.insurance.authenticator.AuthInterceptor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;

@Configuration //Implements Spring’s interface to customize MVC behavior
public class WebConfig implements WebMvcConfigurer {

    private final AuthInterceptor authInterceptor;

    //dependency injection using constructor
    public WebConfig(AuthInterceptor authInterceptor) {
        this.authInterceptor = authInterceptor;
    }

    @Override //Registers your AuthInterceptor so it runs on every request.
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(authInterceptor); // this add the interceptor to spring MVC pipeline
    }

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/uploads/**")
                .addResourceLocations("file:uploads/");
    }

    public class SecurityConfig {
        @Bean // marked it as bean so that spring will configure it
        public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
            http.csrf(csrf -> csrf.disable())
                    .authorizeRequests().anyRequest().permitAll();
            return http.build();
        }
    }
}