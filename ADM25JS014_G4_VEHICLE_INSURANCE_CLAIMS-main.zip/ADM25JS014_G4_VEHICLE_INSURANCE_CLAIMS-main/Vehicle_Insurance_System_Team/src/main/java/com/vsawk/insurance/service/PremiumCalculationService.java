package com.vsawk.insurance.service;

import org.springframework.stereotype.Service;
import java.time.LocalDate;

// This service calculates insurance premium based on vehicle type and age
@Service
public class PremiumCalculationService {

    // Main method to calculate premium - takes vehicle type and year, returns premium amount
    public double calculatePremium(String vehicleType, int vehicleYear) {
        double basePremium = getBasePremium(vehicleType);  // Get base price for vehicle type
        double ageFactor = calculateAgeFactor(vehicleYear);  // Get discount/extra based on age
        return Math.round(basePremium * ageFactor);  // Multiply base price with age factor
    }

    // Set base premium amount for different vehicle types
    private double getBasePremium(String vehicleType) {
        return switch (vehicleType.toLowerCase()) {
            case "car" -> 8000.0;      // Cars cost 8000 rupees base premium
            case "bike" -> 3000.0;     // Bikes cost 3000 rupees base premium
            case "truck" -> 15000.0;   // Trucks cost 15000 rupees base premium
            default -> 5000.0;         // Other vehicles cost 5000 rupees
        };
    }

    // Calculate discount or extra charge based on vehicle age
    private double calculateAgeFactor(int vehicleYear) {
        int currentYear = LocalDate.now().getYear();  // Get current year
        int vehicleAge = currentYear - vehicleYear;   // Calculate how old the vehicle is
        
        if (vehicleAge <= 2) return 1.2;   // New vehicles (0-2 years) - 20% extra charge
        if (vehicleAge <= 5) return 1.0;   // Medium age (3-5 years) - normal price
        if (vehicleAge <= 10) return 0.8;  // Older vehicles (6-10 years) - 20% discount
        return 0.6;                         // Very old vehicles (10+ years) - 40% discount
    }
}