package com.vsawk.insurance.controller;

import com.vsawk.insurance.model.Claim;
import com.vsawk.insurance.model.Policy;
import com.vsawk.insurance.service.ClaimService;
import com.vsawk.insurance.service.PolicyService;
import com.vsawk.insurance.service.ExcelService;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import jakarta.servlet.http.HttpSession;
import java.util.List;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.beans.factory.annotation.Autowired;

@Controller
@RequestMapping("/admin")
public class AdminController {

    private final ClaimService claimService;

    private final PolicyService policyService;

    private final ExcelService excelService;

    @Autowired
    public AdminController(ClaimService claimService, PolicyService policyService, ExcelService excelService) {
        this.claimService = claimService;
        this.policyService = policyService;
        this.excelService = excelService;
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model, HttpSession session) {

        
        List<Policy> allPolicies = policyService.getAllPolicies();
        List<Claim> allClaims = claimService.getAllClaims();
        
        model.addAttribute("totalPolicies", allPolicies.size());
        model.addAttribute("totalClaims", allClaims.size());
        model.addAttribute("pendingClaims", allClaims.stream().filter(c -> c.getClaimStatus() == Claim.ClaimStatus.SUBMITTED).count());
        model.addAttribute("approvedClaims", allClaims.stream().filter(c -> c.getClaimStatus() == Claim.ClaimStatus.APPROVED).count());
        
        // Get recent claims (last 5)
        List<Claim> recentClaims = allClaims.stream()
                .sorted((c1, c2) -> c2.getClaimDate().compareTo(c1.getClaimDate()))
                .limit(5)
                .toList();
        model.addAttribute("recentClaims", recentClaims);
        
        return "admin/dashboard";
    }

    @GetMapping("/claims")
    public String claimsDetails(Model model, HttpSession session) {

        
        model.addAttribute("claims", claimService.getAllClaims().stream()
                                                              .sorted((c1, c2) -> c2.getClaimDate().compareTo(c1.getClaimDate())).toList());
        return "admin/claim_details";
    }

    @GetMapping("/policies")
    public String policiesDetails(Model model, HttpSession session) {

        model.addAttribute("policies", policyService.getAllPolicies());
        return "admin/policy_details";
    }

    @PostMapping("/claims/approve")
    public String approveClaim(@RequestParam Integer claimId, HttpSession session, 
                              RedirectAttributes redirectAttributes) {

        Claim claim = claimService.updateClaimStatus(claimId, Claim.ClaimStatus.APPROVED);
        if (claim != null) {
            redirectAttributes.addFlashAttribute("success", "Claim " + claimId + " has been approved.");
        } else {
            redirectAttributes.addFlashAttribute("error", "Failed to approve claim " + claimId);
        }
        return "redirect:/admin/claims";
    }

    @PostMapping("/claims/reject")
    public String rejectClaim(@RequestParam Integer claimId, @RequestParam String rejectionReason,
                             HttpSession session, org.springframework.web.servlet.mvc.support.RedirectAttributes redirectAttributes) {

        
        Claim claim = claimService.updateClaimStatus(claimId, Claim.ClaimStatus.REJECTED, rejectionReason);
        if (claim != null) {
            redirectAttributes.addFlashAttribute("success", "Claim " + claimId + " has been rejected. Reason: " + rejectionReason);
        } else {
            redirectAttributes.addFlashAttribute("error", "Failed to reject claim " + claimId);
        }
        return "redirect:/admin/claims";
    }

    @GetMapping("/download-claims-report")
    public ResponseEntity<byte[]> downloadClaimsReport(HttpSession session) {

        
        try {
            List<Claim> claims = claimService.getAllClaims();
            byte[] excelData = excelService.generateClaimsExcelReport(claims);
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=claims-report.xlsx")
                    .contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .body(excelData);
        } catch (Exception e) {
            return ResponseEntity.status(500).build();
        }
    }

    @GetMapping("/download-policies-report")
    public ResponseEntity<byte[]> downloadPoliciesReport(HttpSession session) {

        
        try {
            List<Policy> policies = policyService.getAllPolicies();
            byte[] excelData = excelService.generatePoliciesExcelReport(policies);
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=policies-report.xlsx")
                    .contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .body(excelData);
        } catch (Exception e) {
            return ResponseEntity.status(500).build();
        }
    }


}