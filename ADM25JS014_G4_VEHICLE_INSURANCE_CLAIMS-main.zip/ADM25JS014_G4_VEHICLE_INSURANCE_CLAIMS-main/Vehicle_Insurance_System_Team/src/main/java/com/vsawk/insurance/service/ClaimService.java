package com.vsawk.insurance.service;

import com.vsawk.insurance.model.Claim;
import com.vsawk.insurance.repository.ClaimRepository;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.ArrayList;
import java.util.UUID;
import java.math.BigDecimal;
import java.time.LocalDate;
import org.springframework.beans.factory.annotation.Autowired;

@Service
public class ClaimService {

    private final ClaimRepository claimRepository;
    private final PolicyService policyService;

    @Autowired
    public ClaimService(ClaimRepository claimRepository, PolicyService policyService) {
        this.claimRepository = claimRepository;
        this.policyService = policyService;
    }


    public List<Claim> getClaimsByCustomer(Integer customerId) {
        List<Integer> policyIds = new ArrayList<>();
        policyService.getPoliciesByCustomer(customerId).forEach(policy -> policyIds.add(policy.getPolicyId()));
        if (policyIds.isEmpty()) {
            return new ArrayList<>();
        }
        return claimRepository.findByPolicyIdsOrderByClaimIdDesc(policyIds);
    }

    public List<Claim> getAllClaims() {
        return claimRepository.findAll();
    }
    
    public Claim createClaim(Integer policyId, Double claimAmount, String claimReason) {
        Claim claim = new Claim();
        claim.setPolicyId(policyId);
        claim.setClaimAmount(BigDecimal.valueOf(claimAmount));
        claim.setClaimReason(claimReason);
        claim.setClaimDate(LocalDate.now());
        claim.setClaimStatus(Claim.ClaimStatus.SUBMITTED);
        return claimRepository.save(claim);
    }
    
    public Claim getClaimById(Integer id) {
        return claimRepository.findById(id).orElse(null);
    }
    
    public Claim updateClaimStatus(Integer claimId, Claim.ClaimStatus status) {
        Claim claim = claimRepository.findById(claimId).orElse(null);
        if (claim != null) {
            claim.setClaimStatus(status);
            return claimRepository.save(claim);
        }
        return null;
    }

    public Claim updateClaimStatus(Integer claimId, Claim.ClaimStatus status, String rejectionReason) {
        Claim claim = claimRepository.findById(claimId).orElse(null);
        if (claim != null) {
            claim.setClaimStatus(status);
            if (status == Claim.ClaimStatus.REJECTED && rejectionReason != null) {
                claim.setRejectionReason(rejectionReason);
            }
            return claimRepository.save(claim);
        }
        return null;
    }

    public Claim createClaimWithFile(Integer policyId, Double claimAmount, String claimReason, MultipartFile file) throws IOException {
        Claim claim = createClaim(policyId, claimAmount, claimReason);
        
        String fileName = UUID.randomUUID().toString() + "_" + file.getOriginalFilename();
        Path uploadPath = Paths.get(System.getProperty("user.dir"), "uploads", "claims");
        if (!Files.exists(uploadPath)) {
            Files.createDirectories(uploadPath);
        }
        Files.copy(file.getInputStream(), uploadPath.resolve(fileName));
        claim.setAttachmentFileName(fileName);
        return claimRepository.save(claim);
    }
}