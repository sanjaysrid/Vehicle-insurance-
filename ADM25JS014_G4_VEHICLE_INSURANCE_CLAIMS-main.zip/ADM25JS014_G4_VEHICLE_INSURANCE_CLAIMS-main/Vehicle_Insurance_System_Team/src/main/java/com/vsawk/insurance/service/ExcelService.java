package com.vsawk.insurance.service;

import com.vsawk.insurance.model.Claim;
import com.vsawk.insurance.model.Policy;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

@Service
public class ExcelService {

    public byte[] generateClaimsExcelReport(List<Claim> claims) throws IOException {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Claims Report");

        // Create header row
        Row headerRow = sheet.createRow(0);
        headerRow.createCell(0).setCellValue("Claim ID");
        headerRow.createCell(1).setCellValue("Policy ID");
        headerRow.createCell(2).setCellValue("Claim Amount");
        headerRow.createCell(3).setCellValue("Claim Reason");
        headerRow.createCell(4).setCellValue("Status");
        headerRow.createCell(5).setCellValue("Claim Date");

        // Create data rows
        int rowNum = 1;
        for (Claim claim : claims) {
            Row row = sheet.createRow(rowNum++);
            row.createCell(0).setCellValue(claim.getClaimId());
            row.createCell(1).setCellValue(claim.getPolicy() != null ? claim.getPolicy().getPolicyNumber() : "N/A");
            row.createCell(2).setCellValue(claim.getClaimAmount().doubleValue());
            row.createCell(3).setCellValue(claim.getClaimReason());
            row.createCell(4).setCellValue(claim.getClaimStatus().toString());
            row.createCell(5).setCellValue(claim.getClaimDate().toString());
        }

        // Auto-size columns starts from row 1 since 0 is for header
        for (int i = 0; i < 6; i++) {
            sheet.autoSizeColumn(i);
        }

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        workbook.write(outputStream);
        workbook.close();
        return outputStream.toByteArray();
    }

    public byte[] generatePoliciesExcelReport(List<Policy> policies) throws IOException {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Policies Report");

        // Create header row
        Row headerRow = sheet.createRow(0);
        headerRow.createCell(0).setCellValue("Policy ID");
        headerRow.createCell(1).setCellValue("Vehicle Registration");
        headerRow.createCell(2).setCellValue("Premium Amount");
        headerRow.createCell(3).setCellValue("Coverage Amount");
        headerRow.createCell(4).setCellValue("Status");
        headerRow.createCell(5).setCellValue("Start Date");
        headerRow.createCell(6).setCellValue("End Date");

        // Create data rows
        int rowNum = 1;
        for (Policy policy : policies) {
            Row row = sheet.createRow(rowNum++);
            row.createCell(0).setCellValue(policy.getPolicyNumber());
            row.createCell(1).setCellValue(policy.getVehicle() != null ? policy.getVehicle().getRegistrationNumber() : "N/A");
            row.createCell(2).setCellValue(policy.getPremiumAmount().doubleValue());
            row.createCell(3).setCellValue(policy.getCoverageAmount().doubleValue());
            row.createCell(4).setCellValue(policy.getPolicyStatus().toString());
            row.createCell(5).setCellValue(policy.getStartDate().toString());
            row.createCell(6).setCellValue(policy.getEndDate().toString());
        }

        // Auto-size columns
        for (int i = 0; i < 7; i++) {
            sheet.autoSizeColumn(i);
        }

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        workbook.write(outputStream);
        workbook.close();
        return outputStream.toByteArray();
    }
}