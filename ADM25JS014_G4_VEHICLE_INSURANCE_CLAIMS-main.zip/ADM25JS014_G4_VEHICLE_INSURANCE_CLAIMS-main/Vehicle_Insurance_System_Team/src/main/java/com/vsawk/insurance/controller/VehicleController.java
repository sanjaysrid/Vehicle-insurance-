package com.vsawk.insurance.controller;

import com.vsawk.insurance.model.Customer;
import com.vsawk.insurance.model.Vehicle;
import com.vsawk.insurance.service.VehicleService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;


@Controller
@RequestMapping("/vehicle")
public class VehicleController {

    private VehicleService vehicleService;

    @Autowired
    public VehicleController(VehicleService vehicleService) {
        this.vehicleService = vehicleService;
    }

    @GetMapping("/{vehicleId}")
    public String getVehicleDetails(@PathVariable Integer vehicleId, Model model) {
        Vehicle vehicle = vehicleService.getVehicleDetails(vehicleId);
        model.addAttribute("vehicle", vehicle);
        return "vehicle_details";
    }

    @PostMapping("/add")
    public String addVehicle(@RequestParam String registrationNumber, @RequestParam String make,
                             @RequestParam String model, @RequestParam String vehicleType,
                             @RequestParam Integer yearOfManufacture, @RequestParam String engineNumber,
                             @RequestParam String chassisNumber, HttpSession session) {
        Customer customer = (Customer) session.getAttribute("currentCustomer");
        vehicleService.addVehicle(customer.getCustomerId(), registrationNumber, make, model,
                vehicleType, yearOfManufacture, engineNumber, chassisNumber);
        return "redirect:/profile";
    }

    @PostMapping("/update")
    public String updateVehicle(@RequestParam Integer vehicleId, @RequestParam String registrationNumber,
                                @RequestParam String make, @RequestParam String model, @RequestParam String vehicleType,
                                @RequestParam Integer yearOfManufacture, @RequestParam String engineNumber,
                                @RequestParam String chassisNumber, HttpSession session) {
        vehicleService.updateVehicle(vehicleId, registrationNumber, make, model,
                vehicleType, yearOfManufacture, engineNumber, chassisNumber);
        return "redirect:/profile";
    }

}