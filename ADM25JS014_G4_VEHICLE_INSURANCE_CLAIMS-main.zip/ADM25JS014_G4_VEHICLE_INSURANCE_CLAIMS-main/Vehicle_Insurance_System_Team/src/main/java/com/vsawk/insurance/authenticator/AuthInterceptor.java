/* If it's public (like /login, /register, /uploads/), it allows it.
*  If it's an admin route (/admin/...), it checks for isAdmin in session.
*  If it's a customer route, it checks for currentCustomer in session.
*  If not authenticated, it redirects to /login */


package com.vsawk.insurance.authenticator;
import jakarta.servlet.http.HttpServletRequest; //Read the incoming HTTP request
import jakarta.servlet.http.HttpServletResponse; //modify the response, like redirecting to /login
import org.springframework.stereotype.Component; //Spring-managed bean
import org.springframework.web.servlet.HandlerInterceptor;
//This interface lets you intercept HTTP requests before they reach controllers.

@Component
public class AuthInterceptor implements HandlerInterceptor { //intercepts requests and checks authentication before allowing access.

    private static final String LOGIN_PAGE = "/login";

    @Override //This method runs before the controller method.
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        String uri = request.getRequestURI(); //Gets the full URL path of the incoming request

        // Skip auth for public pages
        if (uri.equals("/") || uri.equals("/landing") || uri.equals(LOGIN_PAGE) || uri.equals("/register")|| uri.startsWith("/uploads/") || uri.equals("/login/customer") || uri.equals("/login/admin")){
            return true;
        }

        // Admin routes - check admin session
        if (uri.startsWith("/admin")) {
            if (request.getSession().getAttribute("isAdmin") == null) {
                response.sendRedirect(LOGIN_PAGE);
                return false;
            }
            return true;
        }

        // Customer routes - check customer session
        if (request.getSession().getAttribute("currentCustomer") == null) {
            response.sendRedirect(LOGIN_PAGE);
            return false;
        }

        return true;
    }
}