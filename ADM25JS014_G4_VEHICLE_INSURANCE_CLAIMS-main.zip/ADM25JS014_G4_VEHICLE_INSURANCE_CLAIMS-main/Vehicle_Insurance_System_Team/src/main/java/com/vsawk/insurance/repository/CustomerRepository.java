package com.vsawk.insurance.repository;

import com.vsawk.insurance.model.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Integer> {
   //used to retrive data corresponding to the email
    Optional<Customer> findByEmail(String email);
    //used to find data corresponding to the phone number
    Optional<Customer> findByPhone(String phone);
}

//both the methods created here are used to check whether there are any duplicates or not
