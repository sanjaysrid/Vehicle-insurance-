package com.vsawk.insurance.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;

@Entity
@Table(name = "Vehicle")
public class Vehicle {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer vehicleId;

    @Column(name = "customerId")
    private Integer customerId;

    @NotBlank
    @Column(length = 20)
    private String registrationNumber;

    @NotBlank
    @Column(length = 50)
    private String make;

    @NotBlank
    @Column(length = 50)
    private String model;

    private Integer yearOfManufacture;

    @Enumerated(EnumType.STRING)
    private VehicleType vehicleType;

    @Column(length = 50)
    private String engineNumber;

    @Column(length = 50)
    private String chassisNumber;

    @ManyToOne
    @JoinColumn(name = "customerId", insertable = false, updatable = false)
    private Customer customer;

    public enum VehicleType {
        CAR, BIKE, TRUCK
    }

    public Vehicle() {
    }

    public Vehicle(Integer customerId, String registrationNumber, String make, String model, Integer yearOfManufacture, VehicleType vehicleType) {
        this.customerId = customerId;
        this.registrationNumber = registrationNumber;
        this.make = make;
        this.model = model;
        this.yearOfManufacture = yearOfManufacture;
        this.vehicleType = vehicleType;
    }

    public Integer getVehicleId() {
        return vehicleId;
    }

    public void setVehicleId(Integer vehicleId) {
        this.vehicleId = vehicleId;
    }

    public Integer getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Integer customerId) {
        this.customerId = customerId;
    }

    public String getRegistrationNumber() {
        return registrationNumber;
    }

    public void setRegistrationNumber(String registrationNumber) {
        this.registrationNumber = registrationNumber;
    }

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public Integer getYearOfManufacture() {
        return yearOfManufacture;
    }

    public void setYearOfManufacture(Integer yearOfManufacture) {
        this.yearOfManufacture = yearOfManufacture;
    }

    public VehicleType getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(VehicleType vehicleType) {
        this.vehicleType = vehicleType;
    }

    public String getEngineNumber() {
        return engineNumber;
    }

    public void setEngineNumber(String engineNumber) {
        this.engineNumber = engineNumber;
    }

    public String getChassisNumber() {
        return chassisNumber;
    }

    public void setChassisNumber(String chassisNumber) {
        this.chassisNumber = chassisNumber;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
}