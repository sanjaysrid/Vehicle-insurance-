package com.vsawk.insurance.controller;

import com.vsawk.insurance.model.Customer;
import com.vsawk.insurance.service.ClaimService;
import com.vsawk.insurance.service.PolicyService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.multipart.MultipartFile;
import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/claims")
public class ClaimController {

    //declared variable for directing to pages
    private static final String ERROR = "error";

    //declared for constructor injection
    private final ClaimService claimService;
    private final PolicyService policyService;

    @Autowired
    public ClaimController(ClaimService claimService, PolicyService policyService) {
        this.claimService = claimService;
        this.policyService = policyService;
    }

    @GetMapping
    public String claimPage(Model model, HttpSession session) {
        Customer customer = (Customer) session.getAttribute("currentCustomer");
        if (customer == null) return "redirect:/login";
        
        model.addAttribute("policies", policyService.getPoliciesByCustomer(customer.getCustomerId()));
        model.addAttribute("claims", claimService.getClaimsByCustomer(customer.getCustomerId()));
        return "claims";
    }

    @PostMapping("/create")
    public String createClaim(@RequestParam Integer policyId, @RequestParam Double claimAmount, 
                             @RequestParam String claimReason, @RequestParam("attachment") MultipartFile file,
                             HttpSession session, RedirectAttributes redirectAttributes) {
        Customer customer = (Customer) session.getAttribute("currentCustomer");
        if (customer == null) return "redirect:/login";
        
        try {
            var policy = policyService.getPolicyById(policyId);
            if (policy != null && claimAmount > policy.getCoverageAmount().doubleValue()) {
                redirectAttributes.addFlashAttribute(ERROR, "Claim amount cannot exceed coverage amount of ₹" + policy.getCoverageAmount());
                return "redirect:/claims";
            }
            
            claimService.createClaimWithFile(policyId, claimAmount, claimReason, file);
            redirectAttributes.addFlashAttribute("success", "Claim submitted successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute(ERROR, "Error submitting claim: " + e.getMessage());
        }
        return "redirect:/claims";
    }

}