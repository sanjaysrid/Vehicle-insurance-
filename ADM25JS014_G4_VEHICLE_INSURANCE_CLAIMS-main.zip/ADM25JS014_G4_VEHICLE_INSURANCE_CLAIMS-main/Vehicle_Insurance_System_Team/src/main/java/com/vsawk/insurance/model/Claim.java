package com.vsawk.insurance.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "Claim")
public class Claim {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer claimId;

	@Column(name = "policyId")
	private Integer policyId;

	@Column(precision = 10, scale = 2)
	private BigDecimal claimAmount;

	@Column(columnDefinition = "TEXT")
	private String claimReason;

	private LocalDate claimDate;

	@Enumerated(EnumType.STRING)
	private ClaimStatus claimStatus;

	@Column(columnDefinition = "TEXT")
	private String rejectionReason;

	@Column(length = 255)
	private String attachmentFileName;

	@ManyToOne
	@JoinColumn(name = "policyId", insertable = false, updatable = false)
	private Policy policy;

	public enum ClaimStatus {
		SUBMITTED, APPROVED, REJECTED
	}

	public Claim() {
		this.claimDate = LocalDate.now();
		this.claimStatus = ClaimStatus.SUBMITTED;
	}

	public Claim(Integer policyId, BigDecimal claimAmount, String claimReason) {
		this.policyId = policyId;
		this.claimAmount = claimAmount;
		this.claimReason = claimReason;
		this.claimDate = LocalDate.now();
		this.claimStatus = ClaimStatus.SUBMITTED;
	}

	public Integer getClaimId() {
		return claimId;
	}

	public void setClaimId(Integer claimId) {
		this.claimId = claimId;
	}

	public Integer getPolicyId() {
		return policyId;
	}

	public void setPolicyId(Integer policyId) {
		this.policyId = policyId;
	}

	public BigDecimal getClaimAmount() {
		return claimAmount;
	}

	public void setClaimAmount(BigDecimal claimAmount) {
		this.claimAmount = claimAmount;
	}

	public String getClaimReason() {
		return claimReason;
	}

	public void setClaimReason(String claimReason) {
		this.claimReason = claimReason;
	}

	public LocalDate getClaimDate() {
		return claimDate;
	}

	public void setClaimDate(LocalDate claimDate) {
		this.claimDate = claimDate;
	}

	public ClaimStatus getClaimStatus() {
		return claimStatus;
	}

	public void setClaimStatus(ClaimStatus claimStatus) {
		this.claimStatus = claimStatus;
	}

	public Policy getPolicy() {
		return policy;
	}

	public void setPolicy(Policy policy) {
		this.policy = policy;
	}

	public String getRejectionReason() {
		return rejectionReason;
	}

	public void setRejectionReason(String rejectionReason) {
		this.rejectionReason = rejectionReason;
	}

	public String getAttachmentFileName() {
		return attachmentFileName;
	}

	public void setAttachmentFileName(String attachmentFileName) {
		this.attachmentFileName = attachmentFileName;
	}
}