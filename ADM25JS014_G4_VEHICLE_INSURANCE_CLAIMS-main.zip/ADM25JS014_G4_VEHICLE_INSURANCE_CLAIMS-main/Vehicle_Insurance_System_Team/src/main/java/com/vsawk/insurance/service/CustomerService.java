package com.vsawk.insurance.service;

import com.vsawk.insurance.model.Customer;
import com.vsawk.insurance.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Optional;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

@Service
public class CustomerService {

    private final CustomerRepository customerRepository;
    private final PasswordEncoder passwordEncoder;

    @Autowired
    public CustomerService(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
        this.passwordEncoder = new BCryptPasswordEncoder();
    }


    //for the customer page edit option
    public Customer updateCustomerProfile(Customer customer) {
        Customer existingCustomer = customerRepository.findById(customer.getCustomerId()).orElse(null);
        if (existingCustomer != null) {
            existingCustomer.setName(customer.getName());
            existingCustomer.setEmail(customer.getEmail());
            existingCustomer.setPhone(customer.getPhone());
            existingCustomer.setAddress(customer.getAddress());
            return customerRepository.save(existingCustomer);
        }
        return null;
    }

    //will fetch the data from the database using find by(inbuilt function of JPA)


    // can be used to fetch data based on the customer Id who is logged in
    public Customer getCustomerById(Integer customerId) {
        return customerRepository.findById(customerId).orElse(null);
    }

    
    public Customer authenticateCustomer(String email, String password) {
        Optional<Customer> customer = customerRepository.findByEmail(email);
        if (customer.isPresent() && passwordEncoder.matches(password, customer.get().getPassword())) {
            return customer.get();
        }
        return null;
    }
    
    public Customer registerCustomer(String name, String email, String phone, String address, String password) {
        // Check for duplicate email
        if (customerRepository.findByEmail(email).isPresent()) {
            throw new RuntimeException("Email already exists");
        }
        // Check for duplicate phone
        if (customerRepository.findByPhone(phone).isPresent()) {
            throw new RuntimeException("Phone number already exists");
        }
        Customer customer = new Customer();
        customer.setName(name);
        customer.setEmail(email);
        customer.setPhone(phone);
        customer.setAddress(address);
        String hashedPassword = passwordEncoder.encode(password);
        customer.setPassword(hashedPassword);
        return customerRepository.save(customer);
    }
}