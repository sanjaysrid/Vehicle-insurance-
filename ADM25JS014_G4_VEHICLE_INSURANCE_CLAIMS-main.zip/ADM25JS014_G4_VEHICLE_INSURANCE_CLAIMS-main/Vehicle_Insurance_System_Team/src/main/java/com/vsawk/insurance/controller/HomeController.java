package com.vsawk.insurance.controller;

import com.vsawk.insurance.model.Customer;
import com.vsawk.insurance.model.Policy;
import com.vsawk.insurance.model.Claim;
import com.vsawk.insurance.service.CustomerService;
import com.vsawk.insurance.service.ClaimService;
import com.vsawk.insurance.service.PolicyService;
import com.vsawk.insurance.service.VehicleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model; // Passes data to the view
import org.springframework.web.bind.annotation.*;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import jakarta.servlet.http.HttpSession;
import com.vsawk.insurance.model.Admin;

import com.vsawk.insurance.service.AdminService;



@Controller
public class HomeController {

    private final CustomerService customerService;

    private final AdminService adminService;

    private final ClaimService claimService;

    private final PolicyService policyService;

    private final VehicleService vehicleService;

    @Autowired
    public HomeController(CustomerService customerService, AdminService adminService, ClaimService claimService, PolicyService policyService, VehicleService vehicleService) {
        this.customerService = customerService;
        this.adminService = adminService;
        this.claimService = claimService;
        this.policyService = policyService;
        this.vehicleService = vehicleService;
    }

    @GetMapping("/")
    public String index() {
        return "landing";
    }
    
    @GetMapping("/landing")
    public String landing() {
        return "landing";
    }

    @GetMapping("/login")
    public String login() {
        return "login";
    }
    
    @PostMapping("/login/customer")
    public String loginPost(@RequestParam String username, @RequestParam String password, Model model, HttpSession session) {
        if (username == null || username.trim().isEmpty()) {
            model.addAttribute("loginError", "Email is required");
            return "login";
        }
        if (password == null || password.trim().isEmpty()) {
            model.addAttribute("loginError", "Password is required");
            return "login";
        }

        Customer customer = customerService.authenticateCustomer(username, password);
        if (customer != null) {
            session.setAttribute("currentCustomer", customer);
            return "redirect:/home";
        }

        model.addAttribute("loginError", "Wrong email id or password");
        return "login";
    }

    @PostMapping("/login/admin")
    public String loginPostAdmin(@RequestParam String username, @RequestParam String password, Model model, HttpSession session) {

        // Try admin authentication
        Admin admin = adminService.authenticateAdmin(username, password);
        if (admin != null) {
            session.setAttribute("isAdmin", true);
            session.setAttribute("currentAdmin", admin);
            return "redirect:/admin/dashboard";
        }

        model.addAttribute("adminError", "Wrong admin username or password");
        return "login";
    }

    @PostMapping("/register")
    public String register(@RequestParam String name, @RequestParam String email, 
                          @RequestParam String phone, @RequestParam String address, 
                          @RequestParam String password, Model model) {
        try {
            if (!email.matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
                model.addAttribute("userError", "Please enter a valid email address");
                return "login";
            }
            if (!phone.matches("^[0-9]{10}$")) {
                model.addAttribute("userError", "Phone number must be exactly 10 digits");
                return "login";
            }
            if (!password.matches("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$")) {
                model.addAttribute("userError", "Password must be 8+ characters with uppercase, lowercase, number and special character");
                return "login";
            }
            
            customerService.registerCustomer(name, email, phone, address, password);
            model.addAttribute("success", "Registration successful! Please login.");
        } catch (Exception e) {
            model.addAttribute("userError", "Registration failed: " + e.getMessage());
        }
        return "login";
    }

    @GetMapping("/home")
    public String home(Model model, HttpSession session) {
        Customer sessionCustomer = (Customer) session.getAttribute("currentCustomer");
        if (sessionCustomer == null) {
            return "redirect:/login";
        }
        
        Customer customer = customerService.getCustomerById(sessionCustomer.getCustomerId());
        model.addAttribute("customer", customer);
        model.addAttribute("vehicles", vehicleService.getVehiclesByCustomer(customer.getCustomerId()));
        model.addAttribute("policies", policyService.getPoliciesByCustomer(customer.getCustomerId()));
        model.addAttribute("claims", claimService.getClaimsByCustomer(customer.getCustomerId()));
        return "home";
    }

    
    @GetMapping("/profile")
    public String profile(Model model, HttpSession session) {
        Customer sessionCustomer = (Customer) session.getAttribute("currentCustomer");
        if (sessionCustomer == null) return "redirect:/login";
        
        Customer customer = customerService.getCustomerById(sessionCustomer.getCustomerId());
        model.addAttribute("customer", customer);
        model.addAttribute("vehicles", vehicleService.getVehiclesByCustomer(customer.getCustomerId()));
        model.addAttribute("policies", policyService.getPoliciesByCustomer(customer.getCustomerId()));
        model.addAttribute("claims", claimService.getClaimsByCustomer(customer.getCustomerId()));
        return "profile";
    }
    

    
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }
    
    @GetMapping("/uploads/claims/{filename}")
    public ResponseEntity<byte[]> viewClaimDocument(@PathVariable String filename) {
        try {
            Path filePath = Paths.get("uploads/claims/" + filename);
            if (!Files.exists(filePath)) {
                return ResponseEntity.notFound().build();
            }
            
            byte[] fileContent = Files.readAllBytes(filePath);
            String contentType = Files.probeContentType(filePath);
            if (contentType == null) {
                contentType = "application/octet-stream";
            }
            
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_TYPE, contentType)
                    .header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=\"" + filename + "\"")
                    .body(fileContent);
        } catch (Exception e) {
            return ResponseEntity.status(500).build();
        }
    }
    
    @GetMapping("/profile/download-policy/{policyId}")
    public ResponseEntity<byte[]> downloadPolicyPdf(@PathVariable Integer policyId, HttpSession session) {
        Customer customer = (Customer) session.getAttribute("currentCustomer");
        if (customer == null) return ResponseEntity.status(401).build();
        
        try {
            Policy policy = policyService.getPolicyById(policyId);
            if (policy == null) return ResponseEntity.notFound().build();
            
            // Simple PDF content
            String content = "Policy Details\n\nPolicy Number: " + policy.getPolicyNumber() + 
                           "\nPremium Amount: ₹" + policy.getPremiumAmount() +
                           "\nCoverage Amount: ₹" + policy.getCoverageAmount() +
                           "\nStart Date: " + policy.getStartDate() +
                           "\nEnd Date: " + policy.getEndDate() +
                           "\nStatus: " + policy.getPolicyStatus();
            
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=policy-" + policyId + ".txt")
                    .contentType(MediaType.TEXT_PLAIN)
                    .body(content.getBytes());
        } catch (Exception e) {
            return ResponseEntity.status(500).build();
        }
    }
    
    @GetMapping("/profile/download-claim/{claimId}")
    public ResponseEntity<byte[]> downloadClaimPdf(@PathVariable Integer claimId, HttpSession session) {
        Customer customer = (Customer) session.getAttribute("currentCustomer");
        if (customer == null) return ResponseEntity.status(401).build();
        
        try {
            Claim claim = claimService.getClaimById(claimId);
            if (claim == null) return ResponseEntity.notFound().build();
            
            // Simple PDF content
            String content = "Claim Details\n\nClaim ID: " + claim.getClaimId() + 
                           "\nClaim Amount: ₹" + claim.getClaimAmount() +
                           "\nClaim Reason: " + claim.getClaimReason() +
                           "\nClaim Date: " + claim.getClaimDate() +
                           "\nStatus: " + claim.getClaimStatus() +
                           (claim.getRejectionReason() != null ? "\nRejection Reason: " + claim.getRejectionReason() : "") +
                           (claim.getAttachmentFileName() != null ? "\nAttachment: " + claim.getAttachmentFileName() : "");
            
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=claim-" + claimId + ".txt")
                    .contentType(MediaType.TEXT_PLAIN)
                    .body(content.getBytes());
        } catch (Exception e) {
            return ResponseEntity.status(500).build();
        }
    }

}