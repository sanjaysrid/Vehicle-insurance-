package com.vsawk.insurance.service;

import com.vsawk.insurance.model.Vehicle;
import com.vsawk.insurance.repository.VehicleRepository;
import org.springframework.stereotype.Service;
import java.util.List;


@Service
public class VehicleService {
    

    private final VehicleRepository vehicleRepository;

    public VehicleService(VehicleRepository vehicleRepository) {
        this.vehicleRepository = vehicleRepository;
    }

    
    public Vehicle addVehicle(Integer customerId, String registrationNumber, String make, String model, 
                             String vehicleType, Integer yearOfManufacture, String engineNumber, String chassisNumber) {
        Vehicle vehicle = new Vehicle();
        vehicle.setCustomerId(customerId);
        vehicle.setRegistrationNumber(registrationNumber);
        vehicle.setMake(make);
        vehicle.setModel(model);
        vehicle.setVehicleType(Vehicle.VehicleType.valueOf(vehicleType));
        vehicle.setYearOfManufacture(yearOfManufacture);
        vehicle.setEngineNumber(engineNumber);
        vehicle.setChassisNumber(chassisNumber);
        return vehicleRepository.save(vehicle);
    }
    
    public Vehicle updateVehicle(Integer vehicleId, String registrationNumber, String make, String model, 
                               String vehicleType, Integer yearOfManufacture, String engineNumber, String chassisNumber) {
        Vehicle vehicle = vehicleRepository.findById(vehicleId).orElse(null);
        if (vehicle != null) {
            vehicle.setRegistrationNumber(registrationNumber);
            vehicle.setMake(make);
            vehicle.setModel(model);
            vehicle.setVehicleType(Vehicle.VehicleType.valueOf(vehicleType));
            vehicle.setYearOfManufacture(yearOfManufacture);
            vehicle.setEngineNumber(engineNumber);
            vehicle.setChassisNumber(chassisNumber);
            return vehicleRepository.save(vehicle);
        }
        return null;
    }

    public Vehicle getVehicleDetails(Integer vehicleId) {
        return vehicleRepository.findById(vehicleId).orElse(null);
    }

    public List<Vehicle> getVehiclesByCustomer(Integer customerId) {
        return vehicleRepository.findByCustomerId(customerId);
    }
    
    public Vehicle getVehicleById(Integer vehicleId) {
        return vehicleRepository.findById(vehicleId).orElse(null);
    }
}