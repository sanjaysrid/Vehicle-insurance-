/*
 * POLICY SERVICE - Business logic for policy operations
 * This service handles:
 * 1. Creating new policies
 * 2. Renewing expired policies
 * 3. Finding policies by customer
 * 4. Automatically checking for expired policies
 * 5. Calculating premium and coverage amounts
 */
package com.vsawk.insurance.service;

import com.vsawk.insurance.model.Policy;
import com.vsawk.insurance.model.Vehicle;
import com.vsawk.insurance.repository.PolicyRepository;
import com.vsawk.insurance.repository.VehicleRepository;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.math.BigDecimal; // Used for precise monetary calculations
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Service // This class contains business logic
public class PolicyService {

    // Dependencies needed for policy operations
    private final PolicyRepository policyRepository;
    private final VehicleRepository vehicleRepository;
    private final PremiumCalculationService premiumCalculationService;
    private final VehicleService vehicleService;

    // Constructor - Spring automatically injects dependencies
    public PolicyService(PolicyRepository policyRepository,
                         VehicleRepository vehicleRepository,
                         PremiumCalculationService premiumCalculationService,
                         VehicleService vehicleService) {
        this.policyRepository = policyRepository;
        this.vehicleRepository = vehicleRepository;
        this.premiumCalculationService = premiumCalculationService;
        this.vehicleService = vehicleService;
    }

    // Get all policies for a customer (across all their vehicles)
    public List<Policy> getPoliciesByCustomer(Integer customerId) {
        List<Policy> customerPolicies = new ArrayList<>();
        
        // Find all vehicles owned by this customer
        vehicleRepository.findByCustomerId(customerId)
                // For each vehicle, find its policies and add to list
                .forEach(vehicle -> customerPolicies.addAll(
                        policyRepository.findByVehicleId(vehicle.getVehicleId())));
        
        // Check if any policies have expired and update them
        updateExpiredPolicies(customerPolicies);
        return customerPolicies;
    }
    
    // Get only expired policies for a customer (for renewal page)
    public List<Policy> getExpiredPoliciesByCustomer(Integer customerId) {
        List<Policy> allPolicies = getPoliciesByCustomer(customerId);
        
        // Filter to keep only expired policies
        return allPolicies.stream()
            .filter(policy -> policy.getPolicyStatus() == Policy.PolicyStatus.EXPIRED)
            .toList();
    }
    // Check policies and mark expired ones (called automatically)
    private void updateExpiredPolicies(List<Policy> policies) {
        LocalDate today = LocalDate.now();
        
        // Check each policy
        policies.forEach(policy -> {
            // If policy end date is past and still active, mark as expired
            if (policy.getEndDate().isBefore(today) && 
                policy.getPolicyStatus() == Policy.PolicyStatus.ACTIVE) {
                policy.setPolicyStatus(Policy.PolicyStatus.EXPIRED);
                policyRepository.save(policy); // Save the updated status
            }
        });
    }

    // Create a new policy for a vehicle
    public Policy createPolicy(String policyId, Integer vehicleId) {
        // Get vehicle details
        Vehicle vehicle = vehicleService.getVehicleById(vehicleId);
        if (vehicle == null) {
            throw new IllegalArgumentException("Vehicle not found for ID: " + vehicleId);
        }

        // Calculate premium based on vehicle type and age
        double calculatedPremium = premiumCalculationService.calculatePremium(
                vehicle.getVehicleType().name().toLowerCase(),
                vehicle.getYearOfManufacture()
        );

        // Create new policy with calculated values
        Policy policy = new Policy();
        policy.setPolicyNumber(policyId + "-" + System.currentTimeMillis()); // Unique policy number
        policy.setVehicleId(vehicleId); // Link to vehicle
        policy.setPremiumAmount(BigDecimal.valueOf(calculatedPremium));
        policy.setCoverageAmount(BigDecimal.valueOf(calculatedPremium * 10)); // Coverage is 10x premium
        policy.setStartDate(LocalDate.now()); // Starts today
        policy.setEndDate(LocalDate.now().plusYears(1)); // Ends after 1 year
        policy.setPolicyStatus(Policy.PolicyStatus.ACTIVE); // Set as active

        return policyRepository.save(policy); // Save to database
    }

    // Renew an expired policy
    public Policy renewPolicy(Integer policyId) {
        Policy policy = getPolicyById(policyId);
        if (policy != null) {
            // Extend policy by 1 year from current end date
            policy.setEndDate(policy.getEndDate().plusYears(1));
            // Mark as active again
            policy.setPolicyStatus(Policy.PolicyStatus.ACTIVE);
            return policyRepository.save(policy); // Save updated policy
        }
        return null;
    }

    // Get a single policy by its ID
    public Policy getPolicyById(Integer id) {
        return policyRepository.findById(id).orElse(null);
    }

    // Get all policies in the system (for admin use)
    public List<Policy> getAllPolicies() {
        return policyRepository.findAll();
    }
    
    // Automatic task that runs daily to check for expired policies
    @Scheduled(cron = "0 0 1 * * ?") // Runs every day at 1:00 AM
    public void checkAndUpdateExpiredPolicies() {
        // Get all policies and check if any have expired
        List<Policy> allPolicies = policyRepository.findAll();
        updateExpiredPolicies(allPolicies);
    }
    // Cron format: second minute hour day month dayOfWeek
    // "0 0 1 * * ?" = 0 seconds, 0 minutes, 1 hour, any day, any month, any day of week
}
