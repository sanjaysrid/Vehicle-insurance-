package com.vsawk.insurance.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "Policy")
public class Policy {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer policyId;

    @Column(name = "vehicleId")
    private Integer vehicleId;

    @NotBlank
    @Column(length = 20)
    private String policyNumber;

    @Column(precision = 10, scale = 2)
    private BigDecimal coverageAmount;

    @Column(precision = 10, scale = 2)
    private BigDecimal premiumAmount;

    private LocalDate startDate;
    private LocalDate endDate;

    @Enumerated(EnumType.STRING)
    private PolicyStatus policyStatus;

    @ManyToOne
    @JoinColumn(name = "vehicleId", insertable = false, updatable = false)
    private Vehicle vehicle;

    public enum PolicyStatus {
        ACTIVE, EXPIRED
    }

    public Policy() {}

    public Policy(Integer vehicleId, String policyNumber, BigDecimal coverageAmount, 
                 BigDecimal premiumAmount, LocalDate startDate, LocalDate endDate, PolicyStatus policyStatus) {
        this.vehicleId = vehicleId;
        this.policyNumber = policyNumber;
        this.coverageAmount = coverageAmount;
        this.premiumAmount = premiumAmount;
        this.startDate = startDate;
        this.endDate = endDate;
        this.policyStatus = policyStatus;
    }

    public Integer getPolicyId() {
        return policyId; }
    public void setPolicyId(Integer policyId) { this.policyId = policyId; }

    public Integer getVehicleId() {
        return vehicleId;
    }
    public void setVehicleId(Integer vehicleId) { this.vehicleId = vehicleId; }

    public String getPolicyNumber() { return policyNumber; }
    public void setPolicyNumber(String policyNumber) { this.policyNumber = policyNumber; }

    public BigDecimal getCoverageAmount() { return coverageAmount; }
    public void setCoverageAmount(BigDecimal coverageAmount) { this.coverageAmount = coverageAmount; }

    public BigDecimal getPremiumAmount() { return premiumAmount; }
    public void setPremiumAmount(BigDecimal premiumAmount) { this.premiumAmount = premiumAmount; }

    public LocalDate getStartDate() { return startDate; }
    public void setStartDate(LocalDate startDate) { this.startDate = startDate; }

    public LocalDate getEndDate() { return endDate; }
    public void setEndDate(LocalDate endDate) { this.endDate = endDate; }

    public PolicyStatus getPolicyStatus() { return policyStatus; }
    public void setPolicyStatus(PolicyStatus policyStatus) { this.policyStatus = policyStatus; }

    public Vehicle getVehicle() { return vehicle; }
    public void setVehicle(Vehicle vehicle) { this.vehicle = vehicle; }


}