package com.vsawk.insurance.repository;

import com.vsawk.insurance.model.Claim;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ClaimRepository extends JpaRepository<Claim, Integer> {
    List<Claim> findByPolicyId(Integer policyId);
    
    @Query("SELECT c FROM Claim c WHERE c.policyId IN :policyIds ORDER BY c.claimId DESC")
    List<Claim> findByPolicyIdsOrderByClaimIdDesc(@Param("policyIds") List<Integer> policyIds);

}