
/*
 * POLICY CONTROLLER - Handles all policy-related web requests
 * This controller manages:
 * 1. Showing policy creation page
 * 2. Premium calculation page
 * 3. Policy renewal page
 * 4. Creating new policies
 * 5. Renewing expired policies
 * 6. Calculating premiums via API
 */
package com.vsawk.insurance.controller;

import com.vsawk.insurance.model.Customer;
import com.vsawk.insurance.model.Policy;
import com.vsawk.insurance.model.Vehicle;
import com.vsawk.insurance.service.PolicyService;
import com.vsawk.insurance.service.PremiumCalculationService;
import com.vsawk.insurance.service.VehicleService;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller // This class handles web requests
@RequestMapping("/policy") // All URLs start with /policy
public class PolicyController {
    // constants
    private static final String ATTR_CURRENT_CUSTOMER = "currentCustomer";
    private static final String ATTR_POLICY = "policy";
    // dependency injection
    private final PolicyService policyService;
    private final PremiumCalculationService premiumCalculationService;
    private final VehicleService vehicleService;
   //constructor
    public PolicyController(PolicyService policyService,
                            PremiumCalculationService premiumCalculationService,
                            VehicleService vehicleService) {
        this.policyService = policyService;
        this.premiumCalculationService = premiumCalculationService;
        this.vehicleService = vehicleService;
    }

    @GetMapping("/details/{policyId}")
    public String getPolicyDetails(@PathVariable Integer policyId, Model model) {
        Policy policy = policyService.getPolicyById(policyId);
        model.addAttribute(ATTR_POLICY, policy);
        return "admin/policy_details";
    }

    // GET /policy - Show main policy page with policy types
    @GetMapping
    public String policy() {
        return "policy/index"; // Show policy selection page
    }

    @GetMapping("/premium")
    public String premium(Model model, HttpSession session) { //HttpSession session → Accesses the current user’s session
        Customer customer = (Customer) session.getAttribute(ATTR_CURRENT_CUSTOMER);
        model.addAttribute("vehicles", vehicleService.getVehiclesByCustomer(customer.getCustomerId()));
        return "policy/premium";
    }

    @GetMapping("/renewal")
    public String renewal(Model model, HttpSession session) {
        Customer customer = (Customer) session.getAttribute(ATTR_CURRENT_CUSTOMER);
        model.addAttribute("policies", policyService.getExpiredPoliciesByCustomer(customer.getCustomerId()));
        return "policy/renewal";
    }

    // POST /policy/create - Create new policy (from premium page form)
    @PostMapping("/create")
    public String createPolicy(@RequestParam String policyId, @RequestParam Integer vehicleId,
                               Model model) {
        
        // Create new policy with selected vehicle
        Policy policy = policyService.createPolicy(policyId, vehicleId);
        
        // Add policy and success message to show on success page
        model.addAttribute(ATTR_POLICY, policy);
        model.addAttribute("message", "Policy created and payment processed successfully!");
        return "policy/success"; // Show success page
    }

    // POST /policy/renew - Renew expired policy (from renewal page form)
    @PostMapping("/renew")
    public String renewPolicy(@RequestParam Integer policyId, Model model) {
        // Renew the expired policy
        Policy policy = policyService.renewPolicy(policyId);
        
        // Add policy and success message to show on success page
        model.addAttribute(ATTR_POLICY, policy);
        model.addAttribute("message", "Policy renewed successfully!");
        return "policy/success"; // Show success page
    }



    @GetMapping("/vehicle/{vehicleId}/premium")
    @ResponseBody //Tells Spring that the return value of the method should be written
    // directly to the HTTP response body (instead of rendering a Thymeleaf view).
    public ResponseEntity<Double> calculatePremiumByVehicle(@PathVariable Integer vehicleId) { //A Spring wrapper that represents the full HTTP response (status code + body).
        Vehicle vehicle = vehicleService.getVehicleById(vehicleId);
        if (vehicle == null) {
            return ResponseEntity.notFound().build(); // 404 Not Found
        }
        double premium = premiumCalculationService.calculatePremium(
                vehicle.getVehicleType().name().toLowerCase(),
                vehicle.getYearOfManufacture());
        return ResponseEntity.ok(premium);//Builds a 200 OK HTTP response and The body of the response (JSON number).
    }
}
