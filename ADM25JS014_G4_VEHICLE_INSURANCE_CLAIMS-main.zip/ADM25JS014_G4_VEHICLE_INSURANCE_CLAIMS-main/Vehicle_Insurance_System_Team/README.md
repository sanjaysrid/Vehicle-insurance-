# Vehicle Insurance Policy and Claims Management System

A complete Spring Boot MVC application implementing the exact requirements specification for managing vehicle insurance policies and claims.

## Project Overview

This system implements all 5 modules as specified in the requirements:
1. **Customer Management Module**
2. **Vehicle Management Module** 
3. **Policy Management Module**
4. **Claims Management Module**
5. **Reporting Module**

## Database Schema

The application uses MySQL with the exact schema as specified:

### Tables
- **Customer**: `customerId` (PK), `name`, `email`, `phone`, `address`
- **Vehicle**: `vehicleId` (PK), `customerId` (FK), `registrationNumber`, `make`, `model`, `yearOfManufacture`, `vehicleType` (ENUM)
- **Policy**: `policyId` (PK), `vehicleId` (FK), `policyNumber`, `coverageAmount`, `premiumAmount`, `startDate`, `endDate`, `policyStatus` (ENUM)
- **Claim**: `claimId` (PK), `policyId` (FK), `claimAmount`, `claimReason`, `claimDate`, `claimStatus` (ENUM)

## Technologies Used

- **Backend**: Spring Boot 3.2.0, Spring MVC, Spring Data JPA
- **Frontend**: Thymeleaf, Bootstrap 5.3.2
- **Database**: MySQL 8.0
- **Build Tool**: Maven
- **Java Version**: 17

## Module Implementation

### 1. Customer Management Module
- **Controller**: `CustomerController`
  - `registerCustomer()` - POST `/customer/register`
  - `updateCustomerProfile()` - POST `/customer/update`
  - `getCustomerDetails()` - GET `/customer/{customerId}`
- **Service**: `CustomerService` - Handles business logic for profile operations

### 2. Vehicle Management Module
- **Controller**: `VehicleController`
  - `addVehicle()` - POST `/vehicle/add`
  - `getVehicleDetails()` - GET `/vehicle/{vehicleId}`
  - `updateVehicleDetails()` - POST `/vehicle/update`
- **Service**: `VehicleService` - Validates and processes vehicle data

### 3. Policy Management Module
- **Controller**: `PolicyController`
  - `createPolicy()` - POST `/policy/create`
  - `getPolicyDetails()` - GET `/policy/{policyId}`
  - `renewPolicy()` - POST `/policy/renew`
- **Service**: `PolicyService` - Implements business rules for policies

### 4. Claims Management Module
- **Controller**: `ClaimController`
  - `fileClaim()` - POST `/claims/file`
  - `getClaimStatus()` - GET `/claims/status/{claimId}`
  - `processClaim()` - POST `/claims/process/{claimId}`
- **Service**: `ClaimService` - Validates claims and processes approvals/rejections

### 5. Reporting Module
- **Controller**: `ReportController`
  - `generateClaimReport()` - GET `/reports/claims`
  - `generatePolicyReport()` - GET `/reports/policies`
- **Service**: `ReportService` - Prepares data for reports

## Database Configuration

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/vehicle_insurance_db?createDatabaseIfNotExist=true
spring.datasource.username=root
spring.datasource.password=your_password
```

## How to Run

1. **Prerequisites**:
   - Java 17 or higher
   - Maven 3.6 or higher
   - MySQL 8.0 running on localhost:3306

2. **Setup**:
   ```bash
   cd Vehicle_Insurance_System_Team
   mvn clean install
   mvn spring-boot:run
   ```

3. **Access**:
   - Application: `http://localhost:8081`
   - Login with any credentials to access the system

## Application URLs

- **Login**: `http://localhost:8081/login`
- **Home**: `http://localhost:8081/home`
- **Claims**: `http://localhost:8081/claims`
- **Profile**: `http://localhost:8081/profile`
- **Policy**: `http://localhost:8081/policy`
- **Reports**: `http://localhost:8081/reports/claims` or `http://localhost:8081/reports/policies`

## Sample Data

The application initializes with:
- Customer: SANJAY (ID: 1)
- Vehicles: Toyota Corolla (2020), Honda Accord (2021)
- Policies: Comprehensive (ACTIVE), Third Party (EXPIRED)
- Claims: Various statuses (APPROVED, REJECTED, SUBMITTED)

## Key Features

- **Exact Schema Implementation** as per requirements
- **Complete Module Coverage** with all specified methods
- **Proper Entity Relationships** with foreign keys
- **Enum Types** for vehicle types, policy status, claim status
- **Responsive UI** with Bootstrap
- **Form Validation** and error handling
- **Sample Data** for testing

This implementation fully satisfies the Vehicle Insurance Policy and Claims Management System requirements with proper MVC architecture, database design, and all specified functionalities.